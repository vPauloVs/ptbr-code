from methods.lti import estimate_method, graphics



def estimated_slope(domain: list, image:list, name_file:str) -> tuple:
    sg = estimate_method.StratigraphicRecords(domain, image)
    info_lti_bins, info_lti_acumulative, info_lti_non_acumulative =\
        sg.caller(name_file)
    return info_lti_bins, info_lti_acumulative, info_lti_non_acumulative

def graphic_caller(domain: list, image: list, info_lti_bins: list, 
                   info_lti_acumulative: list, info_lti_non_acumulative: list,
                   name_file: str) -> None:
    
    graphics.plot_readed_data(domain, image, name_file)
    graphics.plot_lti_non_acumulative(info_lti_non_acumulative, name_file)
    graphics.plot_lti_acumulative(info_lti_acumulative, name_file)
    graphics.plot_lti_bins(info_lti_bins, name_file)

def save_csv( info_lti: list, name_file: str, type_results: str) -> None:
    
    info = info_lti
    path = 'results/text_files/csv_files/' + name_file + type_results + '.csv'
    info.to_csv(path, encoding = 'latin1', sep=',', index=False)
        
def receipt_data(domain: list, image: list, name_file: str) -> None:
    
    info_lti_bins, info_lti_acumulative, info_lti_non_acumulative =\
        estimated_slope(domain, image, name_file)
        
    graphic_caller (domain, image, info_lti_bins, info_lti_acumulative, 
                    info_lti_non_acumulative, name_file)
    
    save_csv(info_lti_bins, name_file, '_bins')
    save_csv(info_lti_acumulative, name_file, '_acumulative')
    save_csv(info_lti_non_acumulative, name_file, '_non_acumulative')
    