import matplotlib.pyplot as plt



def plot_readed_data (domain: list, image: list, name_file:str) ->None:
    
    fig = plt.figure(dpi=1800)
    plt.plot(domain, image, lw=0.5, color= 'darkblue')
    
    plt.xlabel('Domain')
    plt.ylabel(f'{name_file}')
    plt.grid(linestyle='--')
    path = 'results/image_files/readed_data/_'+ name_file + '.png'
    
    plt.savefig(path)
    plt.close(fig)
    
def plot_lti_acumulative (info_lti: object, name_file: str) -> None:
    
    layers = info_lti['x'].tolist()
    freq = info_lti['y'].tolist()
    
    fig = plt.figure(dpi=1800)
    plt.plot(layers, freq, color = 'orangered', lw=0.5,
            marker='o', markersize=1)
    
    plt.ylabel('log(N>x)')
    plt.xlabel('log(x)')
    plt.grid(linestyle='--')
    
    path = 'results/image_files/lti_results/_'+name_file+'_acumulative_.png'
    plt.savefig(path)
    plt.close(fig)
    
def plot_lti_bins (info_lti: object, name_file: str) -> None:
    

    limits = info_lti['x'].tolist()
    log_amount_point = info_lti['y'].tolist()
    y_ = info_lti['y_reta'].tolist()
    
    fig = plt.figure(dpi=1800)
    plt.plot(limits, y_, color='darkslategrey', linestyle="--", lw=1)
    
    for i in range(len(limits)):
        plt.plot(limits[i], log_amount_point[i], color='darkslategrey',
                 marker='o', markersize=2)
    
    plt.ylabel('log(N in bin)')
    plt.xlabel('log(x)')
    plt.grid(linestyle='--')
    
    path = 'results/image_files/lti_results/_'+name_file+'_bins.png'
    plt.savefig(path)
    plt.close(fig)
    
def plot_lti_non_acumulative (info_lti: object, name_file: str) -> None:
    
    layers = info_lti['x'].tolist()
    freq = info_lti['y'].tolist()
        
    fig = plt.figure(dpi=1800)
    plt.scatter(layers, freq, color = 'darkred', marker='o', s=4,
                facecolors='none')
    
    plt.ylabel('log(N)')
    plt.xlabel('log(x)')
    
    
    path = 'results/image_files/lti_results/'+name_file+'_non_acumulative_.png'
    plt.savefig(path)
    plt.close(fig)