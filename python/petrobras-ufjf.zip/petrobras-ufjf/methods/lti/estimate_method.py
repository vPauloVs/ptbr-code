import numpy as np
import pandas as pd

class StratigraphicRecords():
    
    def __init__(self, x: list, y: list) -> None:
        self.x = x
        self.y = y
        self.interval = len(y)
        
    def estimate_layers_right (self) -> list:
        length_layers = []
        
        for i in range(self.interval -2):
            if self.y[i+1] >= self.y[i]:
                for j in range(i+2, self.interval):
                    if (self.y[j] <= self.y[i]):
                        break
            else:
                for j in range(i+2, self.interval):
                    if (self.y[j] >= self.y[i]):
                        break
                    
            if j != i+2:
                depth = self.x[j] - self.x[i]
            else:
                depth = 0
            length_layers.append(depth)
            
        length_layers.append(0)  
        length_layers.append(0)
        return length_layers

    def estimate_layers_left (self) -> list:
        length_layers = []
        
        for i in range(self.interval -1, 1, -1):
            if self.y[i-1] >= self.y[i]:
                for j in range(i-2, -2, -1):
                    if (self.y[j] <= self.y[i]) and (j != -1):
                        break
            else:
                for j in range(i-2, -2, -1):
                    if (self.y[j] >= self.y[i]) and (j != -1):
                        break

            if j != i-2:
                depth = self.x[i] - self.x[j+1]
            else:
                depth = 0
            length_layers.append(depth)
            
        length_layers.append(0) 
        length_layers.append(0)
        length_layers.reverse()
        
        return length_layers
               
    def define_layers (self) -> tuple:
        length_layers_right = self.estimate_layers_right()
        length_layers_left = self.estimate_layers_left()
        
        length_layers = length_layers_right + length_layers_left

        sorted_depth = sorted(length_layers)
        return sorted_depth
        

    def tratament_list (self, x: list, y: list) -> tuple:
        
        zero_index = [x.index(element) 
                      for element in x if element==0]
        for index in zero_index:
            x.remove(x[index])
            y.remove(y[index])
            
        zero_index = [y.index(element) 
                      for element in y if element==0]
        for index in zero_index:
            x.remove(x[index])
            y.remove(y[index])
            
        return x, y
    
    def non_acumulative (self, length_layers: list) -> tuple:
        
        freq_non_acumulative = []
        for layer in length_layers:
            count_layers = length_layers.count(layer)
            freq_non_acumulative.append(count_layers)
        
        length_layers, freq_non_acumulative = self.tratament_list(
            length_layers,freq_non_acumulative)
                
        return  np.log10(length_layers), np.log10(freq_non_acumulative)

    def acumulative (self, length_layers: list) -> tuple:
        
        freq_acumulative = []
        length_layers = sorted(length_layers)
        
        for i in range(len(length_layers)-1):
            aux = length_layers[i+1:]
            if length_layers[i] in aux:
                aux.remove(length_layers[i])
            freq_acumulative.append(len(aux))
        freq_acumulative.append(0)   
        
        length_layers, freq_acumulative = self.tratament_list(
        length_layers,freq_acumulative)
        
        return  np.log10(length_layers), np.log10(freq_acumulative)
    
    def amount_point_bins(self, log_len_layers: list) -> tuple:
        
        bins = round((log_len_layers[-1] - log_len_layers[0])/0.2)
        limits = []
        amount_points = []
        stop = 0
        for i in range(bins+1):
            limits.append(log_len_layers[0] + i*0.2)
        for i in range(1, len(limits)):
            start = limits[i-1]
            end = limits[i]
            
            count = 0
            for j in range(stop, len(log_len_layers)):
                if (log_len_layers[j]>=start) and (log_len_layers[j]<=end):
                    count = count + 1
                else:
                    stop = j
                    break
            amount_points.append(count)
   
        limits.remove(limits[-1])
        limits, amount_points = self.tratament_list(limits, amount_points)

        return limits,  np.log10(amount_points)
 
    def write_txt_result (self, slope: float, linear_coeff: float, 
                          name_file: str) -> None:
        
        path = 'results/text_files/txt_files/'+ name_file + '.txt'
        with open(path, 'w') as txt:
            text = f'Generated results to {name_file} from the lti method: \n'
            text = text + f'y = {round(slope,3)} * x + {round(linear_coeff,3)}'
            txt.write(text)
        
        txt.close()
        
    def estimate_parameters (self, limits: list,
                             log_amount_point: list) -> tuple:
        
        slope, linear_coeff = np.polyfit(limits,
                                    log_amount_point,1)
        return slope, linear_coeff
        
    def linear_regression (self, limits: list,
                           log_amount_point: list, 
                           name_file: str) -> list:
        
        slope, linear_coeff = self.estimate_parameters(limits,
                                                       log_amount_point)
        y_ = [(slope * x) + linear_coeff for x in limits]
        self.write_txt_result(slope, linear_coeff, name_file)
        return y_
    
    
    def create_df_dependence (self, x: list, y: list, 
                             y_: list) -> object: 
        
        columns = ['Rótulo', 'x', 'y', 'y_reta']
        label = ['LTI'] * len(x)
        info_lti = pd.DataFrame(list(zip(label, x, y, y_)),
                                columns = columns)
        return info_lti
    
    
    def create_df (self, x: list, y: list) -> object: 
        
        columns = ['Rótulo', 'x', 'y']
        label = ['LTI'] * len(x)
        info_lti = pd.DataFrame(list(zip(label, x, y)),
                                columns = columns)
        return info_lti
    
        
    def generate_results (self, length_layers: list, name_file: str) -> tuple:
        
        layers_non_acumulative, freq_non_acumulative =\
            self.non_acumulative(length_layers)
        
        layers_acumulative, freq_acumulative = self.acumulative(length_layers)
        
        limits, log_amount_point =\
            self.amount_point_bins(layers_acumulative) 
            
        y_ = self.linear_regression(limits, log_amount_point, name_file)
        
        info_lti_bins = self.create_df_dependence(limits, log_amount_point, y_)
        info_lti_acumulative = self.create_df(layers_acumulative, 
                                              freq_acumulative)
        info_lti_non_acumulative = self.create_df(layers_non_acumulative, 
                                              freq_non_acumulative)
        
        return info_lti_bins, info_lti_acumulative, info_lti_non_acumulative

    def caller (self, name_file) -> tuple:
        
        length_layers = self.define_layers()
        info_lti_bins, info_lti_acumulative, info_lti_non_acumulative =\
            self.generate_results(length_layers, name_file)

        return info_lti_bins, info_lti_acumulative, info_lti_non_acumulative
        
