# **Weierstrass Functions for testing fractal methods**

This repository is destined to study fractal methods that furtherly will be applied to stratigraphic data. The Weierstrass functions are test data. 

## **Dependencies**
Requires `Python 3.7` or greater.

Python libraries are listed in `requirements.txt` files.

**To export all libraries requeried to run code, you need to create and use virtual environment:**
- Windowns users:

   `virtualenv --system-site-packages -p python3 ./venv`
   
   `.\venv\activate`
   
- Linux users:

   `source/venv/activate`
