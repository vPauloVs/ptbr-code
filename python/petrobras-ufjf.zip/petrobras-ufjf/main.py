from read_data import read_data
from methods.lti.caller import *



def choose_method (x: list, y: list, model: str, name_file: str) -> None: 
    
    if model == 'lti':
        receipt_data(x, y, name_file)

def main() -> None:
    
    x, y, model, name_file = read_data()
    choose_method(x, y, model, name_file)



