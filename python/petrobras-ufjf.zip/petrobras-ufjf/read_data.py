import pandas as pd 



def read_csv_file(name_file: str, sep: str) -> tuple:
    
    path = 'data/csv_file/' + name_file + '.csv'
    dataframe = pd.read_csv(path)
    columns_to_rename = ['Domain', 'Image']
    for i, colum in enumerate(dataframe.columns):
        dataframe = dataframe.rename(columns={colum:columns_to_rename[i]})
    dataframe = dataframe.sort_values(by=['Domain'])
    return dataframe


def read_excel_file(name_file: str) -> tuple:
    
    path = 'data/excel_file/' + name_file + '.xlsx'
    dataframe = pd.read_excel(path)
    columns_to_rename = ['Domain', 'Image']
    for i, colum in enumerate(dataframe.columns):
        dataframe = dataframe.rename(columns={colum:columns_to_rename[i]})
    dataframe = dataframe.sort_values(by=['Domain'])
    return dataframe


def read_txt_file(name_file: str) -> tuple:
    
    path = 'data/txt_file/' + name_file + '.txt'
    with open(path) as file:
        lines = file.readlines()
        to_data_frame = []
        for i in range (len(lines)-1, -1, -1):
            line = lines[i].split()
            to_data_frame.append((int(line[0]), float(line[1])))
        
    dataframe = pd.DataFrame(to_data_frame, columns=['Domain', 'Image'])
    dataframe = dataframe.sort_values(by=['Domain'])
    return dataframe


def read_data () -> tuple:
    with open('input.txt') as file:
        
        lines = file.readlines()
        lines = lines[:]
        
        name_file = lines[0]
        if '\n' in name_file:
            name_file = name_file[:len(name_file)-1]
            
        extension = lines[1]
        if '\n' in extension:
            extension = extension[:len(extension)-1]
            
        model = lines[2]
        
        if extension == 'csv':
            dataframe = read_csv_file(name_file, sep=',')
        elif extension == 'xlsx':
            dataframe = read_excel_file(name_file)
        elif extension == 'txt':
            dataframe = read_txt_file(name_file)
        else:
            pass
        
        x = dataframe['Domain'].tolist()
        y = dataframe['Image'].tolist()
        
        return x, y, model, name_file
        